from rich.console import Console
from rich.panel import Panel

Console().print(Panel.fit("🎮 [bold]mygame[/bold] loaded", border_style="cyan"))
